# -*- coding: iso-8859-1 -*-
# IMPORTANT! This encoding (charset) setting MUST be correct! If you live in a
# western country and you don't know that you use utf-8, you probably want to
# use iso-8859-1 (or some other iso charset). If you use utf-8 (a Unicode
# encoding) you MUST use: coding: utf-8
# That setting must match the encoding your editor uses when you modify the
# settings below. If it does not, special non-ASCII chars will be wrong.

"""
    MoinMoin - Configuration for a single wiki

    If you run a single wiki only, you can omit the farmconfig.py config
    file and just use wikiconfig.py - it will be used for every request
    we get in that case.

    Note that there are more config options than you'll find in
    the version of this file that is installed by default; see
    the module MoinMoin.config.multiconfig for a full list of names and their
    default values.

    Also, the URL http://moinmo.in/HelpOnConfiguration has
    a list of config options.

    ** Please do not use this file for a wiki farm. Use the sample file
    from the wikifarm directory instead! **
"""

from MoinMoin.config.multiconfig import DefaultConfig
from MoinMoin.auth import BaseAuth, ContinueLogin
from MoinMoin import user


class WordpressAuth(BaseAuth):
    """Authenticate users with a Wordpress database.

    This class has the following module requirements:
    - MySQLdb (http://sourceforge.net/projects/mysql-python)
    - phpass (http://www.openwall.com/phpass/)
    """

    login_inputs = ['username', 'password']
    logout_possible = True
    name = 'wordpress'

    def __init__(self, autocreate=False,
                 db_host='localhost', db_name='',
                 db_user='', db_passwd=''):
        """Initialize class.

        autocreate -- When set to False Moin user accounts are not updated
                      or created.
        db_host -- Hostname where Wordpress DB resides.
        db_name -- Name of Wordpress DB.
        db_user -- Name of DB account with read rights to the wp_user table.
        db_passwd -- Password of DB account.
        """

        BaseAuth.__init__(self)
        self.autocreate = autocreate
        self.db_host = db_host
        self.db_name = db_name
        self.db_user = db_user
        self.db_passwd = db_passwd


    def login(self, request, user_obj, **kw):
        """Handle Moin login request, using Wordpress DB for authentication."""

        username = kw.get('username')
        password = kw.get('password')
        _ = request.getText

        # Continue if user is already valid
        if user_obj and user_obj.valid:
            return ContinueLogin(user_obj)

        if not (username and password):
            return ContinueLogin(user_obj, _("Please enter both user name and password."))

        # Authenticate user and password against Wordpress DB
        row = self.verifyUser(username, password)
        if row:
            user_login, user_pass, user_nicename, user_email = row
            u = user.User(request, auth_username=username, auth_method=self.name, auth_attribs=('name', 'password', 'email', 'aliasname'))
            u.name = user_login
            u.aliasname = user_nicename
            u.email = user_email
            if self.autocreate:
                u.create_or_update(True)
            return ContinueLogin(u)

        return ContinueLogin(user_obj, _("Invalid username or password."))


    def verifyUser(self, username='', password=''):
        """Verify a username and password with a Wordpress database.

        This implementation assumes passwords are hashed using bcrypt, and are
        PHPass compatible.

        username -- Name of Wordpress user.
        password -- Password of Wordpress user.
        """

        import MySQLdb
        db = MySQLdb.connect(host=self.db_host, db=self.db_name, user=self.db_user, passwd=self.db_passwd)
        c = db.cursor()
        q = "SELECT user_login, user_pass, user_nicename, user_email FROM wp_users WHERE user_login='%s'" % (username)
        result = c.execute(q)
        if result == 1:
            row = c.fetchone()
            import phpass  # A bit ugly, but the module is only needed here
            if row and (row[1] == phpass.crypt_private(password, row[1])):
                result = row
            else:
                result = None
        else:
            result = None

        c.close()
        return result


class Config(DefaultConfig):
#~ class FarmConfig(DefaultConfig):

    auth = [WordpressAuth(autocreate=True,
                          db_host='localhost', db_name='wpdb',
                          db_user='wpuser', db_passwd='wppass')]

    user_form_disable = ['name', 'aliasname', 'email',] # don't let the user change these, but show them
    user_form_remove = ['password', 'password2', 'css_url', 'create', 'account_sendmail','jid'] # remove completely

    user_autocreate = True # Is this necessary?


    # Wiki identity ----------------------------------------------------

    # Site name, used by default for wiki name-logo [Unicode]
    sitename = u'MySite'

    # Wiki logo. You can use an image, text or both. [Unicode]
    # For no logo or text, use '' - the default is to show the sitename.
    # See also url_prefix setting below!
    logo_string = u'<img src="/moin_static180/common/moinmoin.png" alt="MoinMoin Logo">'

    # name of entry page / front page [Unicode], choose one of those:

    # a) if most wiki content is in a single language
    page_front_page = u"MyStartingPage"

    # b) if wiki content is maintained in many languages
    #page_front_page = u"FrontPage"

    # The interwiki name used in interwiki links
    #interwikiname = 'UntitledWiki'
    # Show the interwiki name (and link it to page_front_page) in the Theme,
    # nice for farm setups or when your logo does not show the wiki's name.
    #show_interwiki = 1


    # Critical setup  ---------------------------------------------------

    # Misconfiguration here will render your wiki unusable. Check that
    # all directories are accessible by the web server or moin server.

    # If you encounter problems, try to set data_dir and data_underlay_dir
    # to absolute paths.

    # Where your mutable wiki pages are. You want to make regular
    # backups of this directory.
    data_dir = '/path/to/wiki/'

    # Where read-only system and help page are. You might want to share
    # this directory between several wikis. When you update MoinMoin,
    # you can safely replace the underlay directory with a new one. This
    # directory is part of MoinMoin distribution, you don't have to
    # backup it.
    data_underlay_dir = '/path/to/wiki/underlay/'

    # The URL prefix we use to access the static stuff (img, css, js).
    # NOT touching this is maybe the best way to handle this setting as moin
    # uses a good internal default (something like '/moin_static180' for moin
    # version 1.8.0).
    # For Twisted and standalone server, the default will automatically work.
    # For others, you should make a matching server config (e.g. an Apache
    # Alias definition pointing to the directory with the static stuff).
    #url_prefix_static = '/moin_static180'


    # Security ----------------------------------------------------------

    # This is checked by some rather critical and potentially harmful actions,
    # like despam or PackageInstaller action:
    #superuser = [u"YourName", ]

    # IMPORTANT: grant yourself admin rights! replace YourName with
    # your user name. See HelpOnAccessControlLists for more help.
    # All acl_rights_xxx options must use unicode [Unicode]
    acl_rights_before = u"admin:read,write,delete,revert,admin"
    acl_rights_default = u"All:read"

    # The default (ENABLED) password_checker will keep users from choosing too
    # short or too easy passwords. If you don't like this and your site has
    # rather low security requirements, feel free to DISABLE the checker by:
    #password_checker = None # None means "don't do any password strength checks"

    # Link spam protection for public wikis (Uncomment to enable)
    # Needs a reliable internet connection.
    #from MoinMoin.security.antispam import SecurityPolicy


    # Mail --------------------------------------------------------------

    # Configure to enable subscribing to pages (disabled by default)
    # or sending forgotten passwords.

    # SMTP server, e.g. "mail.provider.com" (None to disable mail)
    #mail_smarthost = ""

    # The return address, e.g u"J�rgen Wiki <noreply@mywiki.org>" [Unicode]
    #mail_from = u""

    # "user pwd" if you need to use SMTP AUTH
    #mail_login = ""


    # User interface ----------------------------------------------------

    # Add your wikis important pages at the end. It is not recommended to
    # remove the default links.  Leave room for user links - don't use
    # more than 6 short items.
    # You MUST use Unicode strings here, but you need not use localized
    # page names for system and help pages, those will be used automatically
    # according to the user selected language. [Unicode]
    navi_bar = [
        # If you want to show your page_front_page here:
        #u'%(page_front_page)s',
        u'RecentChanges',
        u'FindPage',
        u'HelpContents',
    ]

    # The default theme anonymous or new users get
    theme_default = 'modern'


    # Language options --------------------------------------------------

    # See http://moinmo.in/ConfigMarket for configuration in
    # YOUR language that other people contributed.

    # The main wiki language, set the direction of the wiki pages
    language_default = 'en'

    # the following regexes should match the complete name when used in free text
    # the group 'all' shall match all, while the group 'key' shall match the key only
    # e.g. CategoryFoo -> group 'all' ==  CategoryFoo, group 'key' == Foo
    # moin's code will add ^ / $ at beginning / end when needed
    # You must use Unicode strings here [Unicode]
    page_category_regex = ur'(?P<all>Category(?P<key>(?!Template)\S+))'
    page_dict_regex = ur'(?P<all>(?P<key>\S+)Dict)'
    page_group_regex = ur'(?P<all>(?P<key>\S+)Group)'
    page_template_regex = ur'(?P<all>(?P<key>\S+)Template)'

    # Content options ---------------------------------------------------

    # Show users hostnames in RecentChanges
    show_hosts = 1

    # Enable graphical charts, requires gdchart.
    #chart_options = {'width': 600, 'height': 300}

